// import React from 'react';
// import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// import ConstructorPage from '@pages/ConstructorPage';
// import AnotherPage from '@pages/AnotherPage';
// import NotFoundPage from '@pages/NotFoundPage';

// const Routes: React.FC = () => (
//   <Router>
//     <Switch>
//       <Route exact path="/" component={ConstructorPage} />
//       <Route path="/another" component={AnotherPage} />
//       <Route component={NotFoundPage} />
//     </Switch>
//   </Router>
// );

// export default Routes;
