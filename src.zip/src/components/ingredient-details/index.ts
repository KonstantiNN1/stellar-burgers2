export { IngredientDetails } from './ingredient-details';
